function obtenerEstacion() {
    const fecha = new Date();
    const dia = fecha.getDate();
    const mes = fecha.getMonth() + 1; // Enero es 0, entonces sumamos 1
   
    var foto = document.getElementById('foto2')
    var EST = document.getElementById('estacionActual')

    

    // Estaciones para el hemisferio norte
    if ((mes === 12 && dia >= 21) || (mes === 1 || mes === 2) || (mes === 3 && dia < 20)) {
        EST.textContent  = "Invierno";
        
        foto.src = "C:/Users/franc/Documents/LLMA/LLMA/estaciones/img/invierno.jpg";
    } else if ((mes === 3 && dia >= 20) || (mes === 4 || mes === 5) || (mes === 6 && dia < 21)) {
        EST.textContent  = "Primavera";
        foto.src = "C:/Users/franc/Documents/LLMA/LLMA/estaciones/img/primaver.jpg";
    } else if ((mes === 6 && dia >= 21) || (mes === 7 || mes === 8) || (mes === 9 && dia < 23)) {
        EST.textContent  = "Verano";
        foto.src = "C:/Users/franc/Documents/LLMA/LLMA/estaciones/img/verano.jpg";
        
    } else if ((mes === 9 && dia >= 23) || (mes === 10 || mes === 11) || (mes === 12 && dia < 21)) {
        EST.textContent  = "Otoño";
        foto.src = "C:/Users/franc/Documents/LLMA/LLMA/estaciones/img/otoño.jpg";
        console.log("Hola")
        EST.textContent = "Otoño"
        
    }

    console.log(`Hoy es ${fecha.toLocaleDateString()}, y estamos en ${EST.textContent }.`);
}

obtenerEstacion()