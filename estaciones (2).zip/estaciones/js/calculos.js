function toggleBackgroundColor() {
    document.body.style.backgroundColor =
        document.body.style.backgroundColor === 'white' ? 'black' : 'white';
}